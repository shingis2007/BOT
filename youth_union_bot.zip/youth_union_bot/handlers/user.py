import logging

from aiogram import F, Router
from aiogram.filters import CommandStart
from aiogram.fsm.context import FSMContext
from aiogram.types import CallbackQuery, Message

import database as db
import keyboards as kb
from states import MurojaatState, RSVPState

logger = logging.getLogger(__name__)
router = Router()


@router.message(CommandStart())
async def cmd_start(message: Message, state: FSMContext):
    await state.clear()
    await db.add_user(message.from_user.id, message.from_user.full_name, message.from_user.username)
    await message.answer(
        f"👋 Assalomu alekum, <b>{message.from_user.full_name}</b>!\n\n"
        "TIIAME Yoshlar Ittifoqi rasmiy botiga xush kelibsiz.",
        reply_markup=kb.user_main_menu(),
    )


@router.message(F.text == "ℹ️ Bot haqida")
async def about(message: Message):
    await message.answer(
        "ℹ️ Bu bot orqali siz:\n"
        "📅 Tadbirlarga yozilishingiz,\n"
        "📨 Murojaat yuborishingiz,\n"
        "👥 Kengash a'zolari bilan tanishishingiz mumkin.\n\n"
        "Savol bo'lsa — 📨 Murojaat yuborish orqali yozing."
    )


# ================= TADBIRLAR / RSVP =================

@router.message(F.text == "📅 Tadbirlar")
async def tadbirlar_list(message: Message):
    tadbirlar = await db.get_tadbirlar()
    if not tadbirlar:
        await message.answer("📅 Hozircha rejalashtirilgan tadbirlar yo'q.")
        return

    for t in tadbirlar:
        text = (
            f"🎉 <b>{t['nomi']}</b>\n"
            f"📆 {t['sana']}\n"
            f"📍 {t['joy']}\n"
            f"📝 {t['tavsif'] or '—'}"
        )
        already = await db.is_already_registered(t["id"], message.from_user.id)
        if already:
            await message.answer(text + "\n\n✅ Siz allaqachon ro'yxatdan o'tgansiz.")
        else:
            await message.answer(text, reply_markup=kb.tadbir_rsvp_kb(t["id"]))


@router.callback_query(F.data.startswith("rsvp_"))
async def rsvp_start(callback: CallbackQuery, state: FSMContext):
    try:
        tadbir_id = int(callback.data.split("_", 1)[1])
    except (IndexError, ValueError):
        await callback.answer("❌ Noto'g'ri so'rov.", show_alert=True)
        return

    tadbir = await db.get_tadbir_by_id(tadbir_id)
    if not tadbir:
        await callback.answer("❌ Bu tadbir topilmadi (o'chirilgan bo'lishi mumkin).", show_alert=True)
        return

    if await db.is_already_registered(tadbir_id, callback.from_user.id):
        await callback.answer("✅ Siz allaqachon ro'yxatdan o'tgansiz.", show_alert=True)
        return

    await state.set_state(RSVPState.telefon)
    await state.update_data(tadbir_id=tadbir_id)
    await callback.message.answer(
        "📱 Ro'yxatdan o'tish uchun telefon raqamingizni yuboring "
        "(pastdagi tugma orqali yoki qo'lda yozib):",
        reply_markup=kb.contact_kb(),
    )
    await callback.answer()


@router.message(RSVPState.telefon, F.text == "❌ Bekor qilish")
async def rsvp_cancel(message: Message, state: FSMContext):
    await state.clear()
    await message.answer("Bekor qilindi.", reply_markup=kb.user_main_menu())


@router.message(RSVPState.telefon, F.contact)
async def rsvp_via_contact(message: Message, state: FSMContext):
    await _finish_rsvp(message, state, message.contact.phone_number)


@router.message(RSVPState.telefon, F.text)
async def rsvp_via_text(message: Message, state: FSMContext):
    await _finish_rsvp(message, state, message.text)


async def _finish_rsvp(message: Message, state: FSMContext, telefon: str) -> None:
    data = await state.get_data()
    tadbir_id = data.get("tadbir_id")
    await state.clear()

    if tadbir_id is None:
        await message.answer("❌ Xatolik yuz berdi. Iltimos, qaytadan urinib ko'ring.", reply_markup=kb.user_main_menu())
        return

    ok = await db.add_qatnashuvchi(
        tadbir_id,
        message.from_user.id,
        message.from_user.full_name,
        message.from_user.username,
        telefon,
    )
    if ok:
        await message.answer("✅ Siz tadbirga muvaffaqiyatli yozildingiz!", reply_markup=kb.user_main_menu())
    else:
        await message.answer("⚠️ Siz allaqachon ro'yxatdan o'tgansiz.", reply_markup=kb.user_main_menu())


# ================= MUROJAAT =================

@router.message(F.text == "📨 Murojaat yuborish")
async def murojaat_start(message: Message, state: FSMContext):
    await state.set_state(MurojaatState.text)
    await message.answer("📨 Murojaatingiz matnini yozing:", reply_markup=kb.cancel_kb())


@router.message(MurojaatState.text)
async def murojaat_send(message: Message, state: FSMContext):
    if message.text == "❌ Bekor qilish":
        await state.clear()
        await message.answer("Bekor qilindi.", reply_markup=kb.user_main_menu())
        return

    if not message.text:
        await message.answer("❌ Iltimos, faqat matn ko'rinishida yuboring:")
        return

    await db.add_murojaat(
        message.from_user.id,
        message.from_user.full_name,
        message.from_user.username,
        message.text,
    )
    await state.clear()
    await message.answer(
        "✅ Murojaatingiz qabul qilindi. Tez orada javob beriladi.",
        reply_markup=kb.user_main_menu(),
    )


# ================= KENGASH A'ZOLARI =================

@router.message(F.text == "👥 Kengash a'zolari")
async def azolar_list(message: Message):
    azolar = await db.get_kengash_azolari()
    if not azolar:
        await message.answer("👥 Hozircha kengash a'zolari kiritilmagan.")
        return

    for a in azolar:
        caption = f"👤 <b>{a['ism']}</b>\n💼 {a['lavozim']}"
        if a.get("username") and a["username"] not in ("-", ""):
            caption += f"\n🔗 {a['username']}"

        if a.get("photo_id"):
            try:
                await message.answer_photo(a["photo_id"], caption=caption)
                continue
            except Exception as e:
                logger.warning("Rasm yuborilmadi (azo #%s): %s", a["id"], e)

        await message.answer(caption)
