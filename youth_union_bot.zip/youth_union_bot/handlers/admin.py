import logging

from aiogram import F, Router
from aiogram.filters import Command
from aiogram.fsm.context import FSMContext
from aiogram.types import Message

import database as db
import keyboards as kb
from config import ADMIN_IDS
from states import AzoState, ElanState, JavobState, OchirishState, TadbirState

logger = logging.getLogger(__name__)
router = Router()


def is_admin(user_id: int) -> bool:
    return user_id in ADMIN_IDS


@router.message(Command("admin"))
async def admin_panel(message: Message):
    if not is_admin(message.from_user.id):
        await message.answer("❌ Sizda admin huquqi yo'q.")
        return
    await message.answer(
        "🔐 <b>Admin panelga xush kelibsiz!</b>",
        reply_markup=kb.admin_main_menu(),
    )


@router.message(F.text == "🔙 Foydalanuvchi menyusi")
async def back_to_user(message: Message, state: FSMContext):
    if not is_admin(message.from_user.id):
        return
    await state.clear()
    await message.answer("Foydalanuvchi menyusi:", reply_markup=kb.user_main_menu())


# ================= STATISTIKA =================

@router.message(F.text == "📊 Statistika")
async def statistika(message: Message):
    if not is_admin(message.from_user.id):
        return
    stats = await db.get_stats()
    await message.answer(
        "📊 <b>Bot statistikasi</b>\n\n"
        f"👥 Foydalanuvchilar: {stats['users']}\n"
        f"📅 Tadbirlar: {stats['tadbirlar']}\n"
        f"🙋 Qatnashuvchilar (jami): {stats['qatnashuvchilar']}\n"
        f"📨 Murojaatlar: {stats['murojaatlar']}\n"
        f"👤 Kengash a'zolari: {stats['azolar']}"
    )


# ================= E'LON =================

@router.message(F.text == "📤 E'lon yuborish")
async def elan_start(message: Message, state: FSMContext):
    if not is_admin(message.from_user.id):
        return
    await state.set_state(ElanState.text)
    await message.answer(
        "📤 Barcha foydalanuvchilarga yuboriladigan e'lon matnini yozing:",
        reply_markup=kb.cancel_kb(),
    )


@router.message(ElanState.text)
async def elan_send(message: Message, state: FSMContext):
    if message.text == "❌ Bekor qilish":
        await state.clear()
        await message.answer("Bekor qilindi.", reply_markup=kb.admin_main_menu())
        return

    if not message.text:
        await message.answer("❌ Iltimos, faqat matn ko'rinishida yuboring:")
        return

    elan_text = message.text
    await state.clear()

    users = await db.get_all_users()
    yuborildi = 0
    xato = 0

    await message.answer(f"⏳ {len(users)} ta foydalanuvchiga yuborilmoqda...")

    for user_id in users.keys():
        try:
            await message.bot.send_message(
                user_id,
                f"📢 <b>E'lon:</b>\n\n{elan_text}",
            )
            yuborildi += 1
        except Exception as e:
            logger.warning("E'lon yuborilmadi (user_id=%s): %s", user_id, e)
            xato += 1

    await message.answer(
        f"✅ E'lon yuborildi!\n✔️ {yuborildi} ta\n❌ {xato} ta xatolik",
        reply_markup=kb.admin_main_menu(),
    )


# ================= TADBIR QO'SHISH =================

@router.message(F.text == "📅 Tadbir qo'shish")
async def tadbir_start(message: Message, state: FSMContext):
    if not is_admin(message.from_user.id):
        return
    await state.set_state(TadbirState.nomi)
    await message.answer("📅 Tadbir nomini kiriting:", reply_markup=kb.cancel_kb())


@router.message(TadbirState.nomi)
async def tadbir_nomi(message: Message, state: FSMContext):
    if message.text == "❌ Bekor qilish":
        await state.clear()
        await message.answer("Bekor qilindi.", reply_markup=kb.admin_main_menu())
        return
    await state.update_data(nomi=message.text)
    await state.set_state(TadbirState.sana)
    await message.answer("📆 Tadbir sanasini kiriting (masalan: 25.09.2026 15:00):")


@router.message(TadbirState.sana)
async def tadbir_sana(message: Message, state: FSMContext):
    if message.text == "❌ Bekor qilish":
        await state.clear()
        await message.answer("Bekor qilindi.", reply_markup=kb.admin_main_menu())
        return
    await state.update_data(sana=message.text)
    await state.set_state(TadbirState.joy)
    await message.answer("📍 Tadbir joyini kiriting:")


@router.message(TadbirState.joy)
async def tadbir_joy(message: Message, state: FSMContext):
    if message.text == "❌ Bekor qilish":
        await state.clear()
        await message.answer("Bekor qilindi.", reply_markup=kb.admin_main_menu())
        return
    await state.update_data(joy=message.text)
    await state.set_state(TadbirState.tavsif)
    await message.answer("📝 Tadbir tavsifini kiriting:")


@router.message(TadbirState.tavsif)
async def tadbir_save(message: Message, state: FSMContext):
    if message.text == "❌ Bekor qilish":
        await state.clear()
        await message.answer("Bekor qilindi.", reply_markup=kb.admin_main_menu())
        return

    data = await state.get_data()
    await db.add_tadbir(data["nomi"], data["sana"], data["joy"], message.text)
    await state.clear()

    await message.answer(
        f"✅ Tadbir qo'shildi!\n\n🎉 <b>{data['nomi']}</b>\n📆 {data['sana']} | 📍 {data['joy']}",
        reply_markup=kb.admin_main_menu(),
    )


# ================= MUROJAATLAR =================

@router.message(F.text == "📨 Murojaatlar")
async def murojaatlar(message: Message):
    if not is_admin(message.from_user.id):
        return

    murojaatlar_list = await db.get_murojaatlar()
    if not murojaatlar_list:
        await message.answer("📨 Hozircha murojaat yo'q.")
        return

    text = f"📨 <b>Jami: {len(murojaatlar_list)} ta murojaat</b> (so'nggi 10 tasi)\n\n"
    for m in murojaatlar_list[-10:]:
        uname = f"@{m['username']}" if m.get("username") else "username yo'q"
        holat = "✅ javob berilgan" if m.get("status") == "javob berildi" else "⏳ kutilmoqda"
        text += (
            f"#{m['id']} | {m['full_name']} ({uname}) — {holat}\n"
            f"📅 {m['date']}\n"
            f"💬 {m['text'][:100]}\n"
            f"📨 Javob berish: /javob_{m['user_id']}\n\n"
        )
    await message.answer(text)


# ================= QATNASHUVCHILAR =================

@router.message(F.text == "🙋 Qatnashuvchilar")
async def qatnashuvchilar(message: Message):
    if not is_admin(message.from_user.id):
        return

    tadbirlar = await db.get_tadbirlar()
    barcha = await db.get_qatnashuvchilar()

    if not barcha:
        await message.answer("🙋 Hozircha hech kim qatnashishini bildirmagan.")
        return

    yuborildi = False
    for t in tadbirlar:
        qlist = barcha.get(str(t["id"]), [])
        if not qlist:
            continue
        yuborildi = True
        text = f"📅 <b>{t['nomi']}</b> — {len(qlist)} ta qatnashuvchi\n\n"
        for i, q in enumerate(qlist, 1):
            uname = f"@{q['username']}" if q.get("username") else "username yo'q"
            telefon = q.get("telefon") or "kiritilmagan"
            text += f"{i}. {q['full_name']} ({uname}) — 📱 {telefon}\n"
        await message.answer(text)

    if not yuborildi:
        await message.answer("🙋 Hozircha hech kim qatnashishini bildirmagan.")


# ================= FOYDALANUVCHILAR =================

@router.message(F.text == "👥 Foydalanuvchilar")
async def foydalanuvchilar(message: Message):
    if not is_admin(message.from_user.id):
        return
    users = await db.get_all_users()
    await message.answer(f"👥 <b>Foydalanuvchilar soni: {len(users)} ta</b>")


# ================= KENGASH A'ZOSI QO'SHISH =================

@router.message(F.text == "➕ Kengash a'zosi qo'shish")
async def azo_start(message: Message, state: FSMContext):
    if not is_admin(message.from_user.id):
        return
    await state.set_state(AzoState.ism)
    await message.answer("👤 A'zoning to'liq ismini kiriting:", reply_markup=kb.cancel_kb())


@router.message(AzoState.ism)
async def azo_ism(message: Message, state: FSMContext):
    if message.text == "❌ Bekor qilish":
        await state.clear()
        await message.answer("Bekor qilindi.", reply_markup=kb.admin_main_menu())
        return
    await state.update_data(ism=message.text)
    await state.set_state(AzoState.lavozim)
    await message.answer("💼 Lavozimini kiriting (masalan: Raisi, Kotibi, Xazinachisi):")


@router.message(AzoState.lavozim)
async def azo_lavozim(message: Message, state: FSMContext):
    if message.text == "❌ Bekor qilish":
        await state.clear()
        await message.answer("Bekor qilindi.", reply_markup=kb.admin_main_menu())
        return
    await state.update_data(lavozim=message.text)
    await state.set_state(AzoState.username)
    await message.answer("🔗 Telegram username kiriting (masalan: @username, bo'lmasa '-' yozing):")


@router.message(AzoState.username)
async def azo_username(message: Message, state: FSMContext):
    if message.text == "❌ Bekor qilish":
        await state.clear()
        await message.answer("Bekor qilindi.", reply_markup=kb.admin_main_menu())
        return
    await state.update_data(username=message.text)
    await state.set_state(AzoState.photo)
    await message.answer(
        "📸 A'zoning rasmini yuboring (bo'lmasa, pastdagi tugmani bosing):",
        reply_markup=kb.skip_kb(),
    )


@router.message(AzoState.photo)
async def azo_photo(message: Message, state: FSMContext):
    if message.text == "❌ Bekor qilish":
        await state.clear()
        await message.answer("Bekor qilindi.", reply_markup=kb.admin_main_menu())
        return

    data = await state.get_data()
    photo_id = message.photo[-1].file_id if message.photo else None

    await db.add_kengash_azosi(data["ism"], data["lavozim"], data["username"], photo_id)
    await state.clear()

    rasm_status = "✅ qo'shildi" if photo_id else "❌ yo'q"
    await message.answer(
        f"✅ Kengash a'zosi qo'shildi!\n\n"
        f"👤 <b>{data['ism']}</b>\n"
        f"💼 {data['lavozim']}\n"
        f"🔗 {data['username']}\n"
        f"📸 Rasm: {rasm_status}",
        reply_markup=kb.admin_main_menu(),
    )


# ================= A'ZONI O'CHIRISH =================

@router.message(F.text == "🗑 A'zoni o'chirish")
async def azo_ochirish(message: Message, state: FSMContext):
    if not is_admin(message.from_user.id):
        return

    azolar = await db.get_kengash_azolari()
    if not azolar:
        await message.answer("👥 Hozircha kengash a'zolari yo'q.")
        return

    text = "🗑 <b>Qaysi a'zoni o'chirmoqchisiz?</b>\n\nID raqamini yozing:\n\n"
    for a in azolar:
        text += f"ID: <code>{a['id']}</code> — {a['ism']} ({a['lavozim']})\n"

    await state.set_state(OchirishState.azo_id)
    await message.answer(text, reply_markup=kb.cancel_kb())


@router.message(OchirishState.azo_id)
async def azo_ochirish_confirm(message: Message, state: FSMContext):
    if message.text == "❌ Bekor qilish":
        await state.clear()
        await message.answer("Bekor qilindi.", reply_markup=kb.admin_main_menu())
        return

    if not message.text or not message.text.isdigit():
        await message.answer("❌ Noto'g'ri ID. Faqat raqam kiriting yoki bekor qiling:")
        return

    azo_id = int(message.text)
    deleted = await db.delete_kengash_azosi(azo_id)
    await state.clear()

    if deleted:
        await message.answer(f"✅ #{azo_id} ID li a'zo o'chirildi.", reply_markup=kb.admin_main_menu())
    else:
        await message.answer(f"⚠️ #{azo_id} ID li a'zo topilmadi.", reply_markup=kb.admin_main_menu())


# ================= MUROJAATGA JAVOB BERISH =================

@router.message(F.text.startswith("/javob_"))
async def javob_start(message: Message, state: FSMContext):
    if not is_admin(message.from_user.id):
        return

    parts = message.text.split("_")
    if len(parts) != 2 or not parts[1].isdigit():
        await message.answer("❌ Noto'g'ri buyruq formati. Masalan: /javob_123456789")
        return

    user_id = int(parts[1])
    await state.set_state(JavobState.text)
    await state.update_data(user_id=user_id)
    await message.answer(
        f"✏️ Foydalanuvchi <code>{user_id}</code> ga javob yozing:",
        reply_markup=kb.cancel_kb(),
    )


@router.message(JavobState.text)
async def javob_send(message: Message, state: FSMContext):
    if message.text == "❌ Bekor qilish":
        await state.clear()
        await message.answer("Bekor qilindi.", reply_markup=kb.admin_main_menu())
        return

    if not message.text:
        await message.answer("❌ Iltimos, faqat matn ko'rinishida yozing:")
        return

    data = await state.get_data()
    user_id = data["user_id"]
    javob_text = message.text
    await state.clear()

    try:
        await message.bot.send_message(
            user_id,
            f"📬 <b>Yoshlar Ittifoqidan javob:</b>\n\n{javob_text}",
        )
        await db.mark_murojaat_answered(user_id, javob_text)
        await message.answer("✅ Javob yuborildi!", reply_markup=kb.admin_main_menu())
    except Exception as e:
        logger.warning("Javob yuborilmadi (user_id=%s): %s", user_id, e)
        await message.answer(
            "❌ Foydalanuvchiga xabar yuborib bo'lmadi "
            "(botni bloklagan yoki hisobini o'chirgan bo'lishi mumkin).",
            reply_markup=kb.admin_main_menu(),
        )
